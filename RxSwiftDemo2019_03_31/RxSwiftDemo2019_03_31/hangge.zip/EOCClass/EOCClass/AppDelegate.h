//
//  AppDelegate.h
//  EOCClass
//
//  Created by 远平 on 2019/11/2.
//  Copyright © 2019 远平. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

