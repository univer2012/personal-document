//
//  EOCLib.h
//  EOCLib
//
//  Created by 远平 on 2019/11/2.
//  Copyright © 2019 远平. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EOCLib : NSObject
+ (void)eocMethod;
@end
