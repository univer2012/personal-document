//
//  main.m
//  EOCClass
//
//  Created by 远平 on 2019/11/2.
//  Copyright © 2019 远平. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
