//
//  ViewController.m
//  EOCClass
//
//  Created by 远平 on 2019/11/2.
//  Copyright © 2019 远平. All rights reserved.
//

#import "ViewController.h"
#import "NSObject+EOC.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [NSObject eocMethod];
    // Do any additional setup after loading the view.
}


@end
