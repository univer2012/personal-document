//
//  EOCFrame.h
//  EOCFrame
//
//  Created by 远平 on 2019/11/2.
//  Copyright © 2019 远平. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for EOCFrame.
FOUNDATION_EXPORT double EOCFrameVersionNumber;

//! Project version string for EOCFrame.
FOUNDATION_EXPORT const unsigned char EOCFrameVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EOCFrame/PublicHeader.h>


