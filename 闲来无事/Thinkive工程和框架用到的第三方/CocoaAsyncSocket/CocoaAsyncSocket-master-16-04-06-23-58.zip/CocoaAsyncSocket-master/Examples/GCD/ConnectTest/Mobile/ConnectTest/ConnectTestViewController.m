#import "ConnectTestViewController.h"


@implementation ConnectTestViewController

@synthesize label = _label;


@end
