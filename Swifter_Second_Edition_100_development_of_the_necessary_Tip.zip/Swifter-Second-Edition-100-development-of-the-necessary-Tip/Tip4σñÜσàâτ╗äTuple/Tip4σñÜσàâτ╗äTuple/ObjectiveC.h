//
//  ObjectiveC.h
//  Tip4多元组Tuple
//
//  Created by huangaengoln on 16/4/3.
//  Copyright © 2016年 huangaengoln. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ObjectiveC : NSObject


@end
